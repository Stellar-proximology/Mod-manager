#!/usr/bin/env python3
"""
Sample test module
"""

def main():
    print("Test module loaded successfully!")
    print("This is a sample Python application")

if __name__ == '__main__':
    main()
